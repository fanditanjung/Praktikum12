@extends('admin.layout.appadmin')

@section('content')
    <h1>Ini adalah halaman Dashboard</h1>
@endsection