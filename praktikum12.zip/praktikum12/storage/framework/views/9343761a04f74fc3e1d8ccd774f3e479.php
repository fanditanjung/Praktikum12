

<?php $__env->startSection('content'); ?>
    <h1>Ini adalah halaman Dashboard</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.appadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\semester 2\praktikum10~\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>